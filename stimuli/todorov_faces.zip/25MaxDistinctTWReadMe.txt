This folder contains 175 faces: 25 maximally distinct face identities that co-vary on 7 levels of shape and reflectance, on the trustworthiness dimension. The faces were generated using FaceGen Modeller 3.2 (Singular Inversions, 2007), according to the methods described in Todorov, A., Dotsch, R., Porter, J., Oosterhof, N., and Falvello, V (2013) Validation of Data-Driven Computational Models of Social Perception of Faces, Emotion. All faces are bald, Caucasian males.

The file names begin with "nexus_2" to indicate they all belong to the same face set. This is followed by a one or two digit number from 1 to 25, which signals a unique face identity, and a number from -3.00 to 3.00, which indicates the trustworthiness level. These levels correspond to the following standard deviations:


-3 sd (less trustworthy)
-2 sd
-1 sd
0 sd (neutral)
1 sd
2 sd 
3 sd (more trustworthy)